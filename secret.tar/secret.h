#ifndef __SECRET_H
#define __SECRET_H

#define SECRET_SIZE 8192

#endif /* __SECRET_H */
